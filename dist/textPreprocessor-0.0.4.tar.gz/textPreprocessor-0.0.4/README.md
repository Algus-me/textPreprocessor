"# textPreprocessor" 

Installation:

pip install textPreprocessor

python -m spacy download en
python -m spacy download de
python -m spacy download es
python -m spacy download pt
python -m spacy download fr
python -m spacy download it
python -m spacy download nl
python -m spacy download xx

if you have windows, download from https://www.lfd.uci.edu/~gohlke/pythonlibs following wheels
PyICU-2.2-cp36-cp36m-win_amd64.whl
Morfessor-2.0.4-py2.py3-none-any.whl
pycld2-0.31-cp36-cp36m-win_amd64.whl

install them through console by
pip install <whl file name>