class TextTokenizer:
    def tokenize(self, text):
        pass